package subsystem;

import entity.payment.PaymentMethod;
import entity.payment.PaymentRequest;
import entity.payment.PaymentTransaction;

/** Payment boundary parameterized by the payment method it supports. */
public interface PaymentGateway<M extends PaymentMethod> {

    PaymentTransaction pay(PaymentRequest<M> request);
}
