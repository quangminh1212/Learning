package subsystem;

import entity.payment.CreditCard;
import entity.payment.PaymentRequest;
import entity.payment.PaymentTransaction;

/** Adapts the existing interbank credit-card API to the typed gateway boundary. */
public final class InterbankCreditCardPaymentGatewayAdapter implements PaymentGateway<CreditCard> {

    private final InterbankInterface interbank;

    public InterbankCreditCardPaymentGatewayAdapter(InterbankInterface interbank) {
        this.interbank = interbank;
    }

    @Override
    public PaymentTransaction pay(PaymentRequest<CreditCard> request) {
        return interbank.payOrder(request.getPaymentMethod(), request.getAmount(), request.getContents());
    }
}
