package entity.order;

/** Immutable delivery details collected for an order. */
public final class DeliveryInfo {

    private final String name;
    private final String phone;
    private final String address;
    private final String province;
    private final String instructions;

    public DeliveryInfo(String name, String phone, String address, String province, String instructions) {
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.province = province;
        this.instructions = instructions;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getProvince() {
        return province;
    }

    public String getInstructions() {
        return instructions;
    }
}
