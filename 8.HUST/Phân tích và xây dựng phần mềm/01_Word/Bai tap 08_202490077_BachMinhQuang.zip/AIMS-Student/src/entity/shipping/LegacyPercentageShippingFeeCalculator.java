package entity.shipping;

import java.util.Random;

/** Preserves the source project's legacy randomized percentage calculation. */
public final class LegacyPercentageShippingFeeCalculator implements ShippingFeeCalculator {

    @Override
    public int calculate(ShippingQuoteRequest request) {
        Random random = new Random();
        return (int) (((random.nextFloat() * 10) / 100) * request.getOrderAmount());
    }
}
