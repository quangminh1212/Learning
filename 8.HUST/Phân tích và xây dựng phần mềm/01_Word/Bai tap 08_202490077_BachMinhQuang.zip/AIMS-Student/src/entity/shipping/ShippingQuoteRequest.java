package entity.shipping;

/** Inputs currently available to quote the legacy shipping fee. */
public final class ShippingQuoteRequest {

    private final int orderAmount;

    public ShippingQuoteRequest(int orderAmount) {
        this.orderAmount = orderAmount;
    }

    public int getOrderAmount() {
        return orderAmount;
    }
}
