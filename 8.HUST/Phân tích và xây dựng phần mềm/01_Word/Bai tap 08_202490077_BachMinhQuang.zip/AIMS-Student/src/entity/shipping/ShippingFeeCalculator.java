package entity.shipping;

/** Calculates a shipping fee from the information currently supplied by the order flow. */
public interface ShippingFeeCalculator {

    int calculate(ShippingQuoteRequest request);
}
