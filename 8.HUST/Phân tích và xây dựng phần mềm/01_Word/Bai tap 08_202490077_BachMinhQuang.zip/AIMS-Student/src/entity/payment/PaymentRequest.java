package entity.payment;

/** Immutable request passed from the payment controller to a gateway. */
public final class PaymentRequest<M extends PaymentMethod> {

    private final M paymentMethod;
    private final int amount;
    private final String contents;

    public PaymentRequest(M paymentMethod, int amount, String contents) {
        this.paymentMethod = paymentMethod;
        this.amount = amount;
        this.contents = contents;
    }

    public M getPaymentMethod() {
        return paymentMethod;
    }

    public int getAmount() {
        return amount;
    }

    public String getContents() {
        return contents;
    }
}
