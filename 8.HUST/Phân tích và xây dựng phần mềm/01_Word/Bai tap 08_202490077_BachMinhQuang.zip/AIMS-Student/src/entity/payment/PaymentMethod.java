package entity.payment;

/** Marker for payment methods accepted by the payment flow. */
public interface PaymentMethod {
}
