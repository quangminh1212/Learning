# Bài tập 08 — Rà soát thiết kế AIMS

## Nội dung gói

- `Bai tap 08_202490077_BachMinhQuang.docx`: báo cáo hoàn thiện từ mẫu bài tập.
- `AIMS-Student/`: snapshot mã nguồn AIMS tại revision được ghi trong `SOURCE_REVISION.txt`.
- `SOURCE_REVISION.txt`: nguồn, revision và SHA-256 của archive gốc.
- `README_BAI_08.md`: hướng dẫn, phạm vi chỉnh sửa và cách biên dịch.

## Các thay đổi trong source

- Thay `HashMap` giao hàng bằng `DeliveryInfo` bất biến gồm tên, điện thoại, địa chỉ, tỉnh và hướng dẫn; hóa đơn hiển thị đủ năm trường.
- Tách `ShippingQuoteRequest` và `ShippingFeeCalculator`; `LegacyPercentageShippingFeeCalculator` giữ nguyên công thức ngẫu nhiên hiện tại.
- Bổ sung `PaymentMethod`, `PaymentRequest<M>`, `PaymentGateway<M>` và adapter cho API interbank hiện hữu; `PaymentController` nhận gateway qua constructor.
- The interbank API logs only request type and HTTP status; it never logs transaction request or response bodies.
- `PaymentTransaction` lưu `PaymentMethod`; `CreditCard` hiện thực abstraction này.
- Bỏ override `DVD.getAllMedia()` trả về `null`, để DVD kế thừa hành vi của `Media`.

## Giới hạn phạm vi

Snapshot được đối chiếu chưa có use case Place Rush Order. Gói không tự thêm cước Rush/SLA, bảng giá, dữ liệu cân nặng/kích thước/khoảng cách, domestic debit card hay provider interbank mới. Các phần đó cần đặc tả và dữ liệu đầu vào trước khi triển khai. Validator giao hàng hiện vẫn rỗng; refund của interbank vẫn là stub trả `null`.

## Biên dịch trên Windows

Dùng JDK 17 và JavaFX 15 đi kèm project. Từ thư mục `AIMS-Student`, chạy PowerShell:

```powershell
$classes = "..\build-classes"
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$javaSources = Get-ChildItem -Path "src" -Filter "*.java" -Recurse | ForEach-Object FullName
javac -encoding UTF-8 --module-path "lib\win\javafx-sdk-15\lib" --add-modules javafx.controls,javafx.fxml -classpath "lib\sqlite-jdbc-3.7.2.jar" -d $classes $javaSources
```

Source đã biên dịch thành công với JDK 17.0.18 và 65 file Java. Output có cảnh báo unchecked operations vốn có trong source. Không có automated test nào được thêm hoặc chạy.

## Nguồn

Mã nguồn được lấy từ [AIMS-Student](https://github.com/leminhnguyen/AIMS-Student), đã resolve tới repository `leminhnguyen/Media-Store-JAVAFX`. Commit và SHA-256 archive được ghi tại `SOURCE_REVISION.txt`.
